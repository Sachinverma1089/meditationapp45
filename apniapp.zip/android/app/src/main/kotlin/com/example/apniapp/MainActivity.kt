package com.example.apniapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
